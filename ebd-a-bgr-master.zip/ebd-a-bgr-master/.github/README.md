
 <h2 align="center">   
    ──「 EBD~QN 𝗩𝗰 𝗣𝗹𝗮𝘆𝗲𝗿 」──  
   </h2>  
 <p align="center">   
<img src="https://telegra.ph/file/2c7df8cf19467cfeb4356.jpg">   
 </p> ━━━━━━━━━━━━━━━━━━━━ 
 <p align="center"> 
 <a href="https://github.com/MrProgrammer72/GJ516VCBOT/stargazers"><img src="https://img.shields.io/github/stars/MrProgrammer72/GJ516VCBOT?color=black&logo=github&logoColor=black&style=for-the-badge" alt="Stars" /></a> <a href="https://github.com/MrProgrammer72/GJ516VCBOT/network/members"> <img src="https://img.shields.io/github/forks/MrProgrammer72/GJ516VCBOT?color=black&logo=github&logoColor=black&style=for-the-badge" /></a> 
 <a href="https://www.python.org/"> <img src="https://img.shields.io/badge/Written%20in-Python-skyblue?style=for-the-badge&logo=python" alt="Python" /> </a> 
 </p> 
 ━━━━━━━━━━━━━━━━━━━━
 <details> 
 <summary> 𝗥𝗲𝗾𝘂𝗶𝗿𝗲𝗺𝗲𝗻𝘁𝘀 📝</summary> 

 - FFmpeg 
 - NodeJS [nodesource.com](https://nodesource.com/) 
 - Python 3.7 or higher 
 - [PyTgCalls](https://github.com/pytgcalls/pytgcalls) 
 </details> 
 <details> 
 <summary> 𝗙𝗲𝗮𝘁𝘂𝗿𝗲𝘀 🔮</summary> 

 - Yt-dL Fix 
 - Updated Plug-in 
 - Super Fast Bot 
 - No Lag Hang 
 - Fast Download Song From Server 
 - Program Updated 
 - Smooth Player 
 </details> 
 <details> 
 <summary> 𝗖𝗼𝗺𝗺𝗮𝗻𝗱𝘀 🛠</summary>
  
 - `/play <song name>` - play song you requested 
 - `/song <song name>` - download songs you want quickly 
 - `/ping` - Bot Online or Offine 

  #### Admins Only 👷‍♂️ 

- `/pause` - pause song play 
 - `/resume` - resume song play 
 - `/skip` - play next song 
 - `/end` - stop music play 
 </details> 

<details>
<summary>𝗦𝗲𝘀𝘀𝗶𝗼𝗻 🥀</summary>

- 🧪 Get `SESSION_NAME` variable: 
  - [``Pyrogram Session``](https://telegram.me/)
 </details>
 
 <details>
<summary> 
𝗗𝗲𝗽𝗹𝗼𝘆𝗺𝗲𝗻𝘁 𝗺𝗲𝘁𝗵𝗼𝗱𝘀 🚀
</summary> 


 ## ᴅᴇᴘʟᴏʏ ᴛᴏ ʜᴇʀᴏᴋᴜ 🚀 

 <p align="center"><a href="https://heroku.com/deploy?template=https://github.com/MrProgrammer72/GJ516Music"> <img src="https://img.shields.io/badge/Deploy%20To%20Heroku-orange?style=for-the-badge&logo=heroku" width="200" height="35.45"/></a></p> 

 The easiest way to host this bot, Deploy on Heroku, Change the app country to Europe (it will help to make the bot more stable). 

 ## ᴅᴇᴩʟᴏʏ ᴏɴ ᴏᴋᴛᴇᴛᴏ 

 <p align="center"><a href="https://cloud.okteto.com/deploy?repository=https://github.com/MrProgrammer72/GJ516Music"><img src="https://img.shields.io/badge/Deploy%20To%20Okteto-informational?style=for-the-badge&logo=Okteto" width="200" height="35.45"/></a></p> 

 The second easiest way to host this bot, Deploy on Okteto Cloud 
 ## ᴅᴇᴘʟᴏʏ ᴏɴ ᴠᴘꜱ ꜱᴇʀᴠᴇʀ's 📡

  <p> 

 - Get your [NecesseryVariables](https://github.com/MrProgrammer72/GJ516Music/blob/master/sample.env) 
 - Upgrade and Update by : 
 `sudo apt-get update && sudo apt-get upgrade -y` 
 - Install required packages by : 
 `sudo apt-get install python3-pip ffmpeg -y` 
 - Install pip by : 
 `sudo pip3 install -U pip` 
 - Install node by : 
 `curl -fssL https://deb.nodesource.com/setup_18.x | sudo -E bash - && sudo apt-get install nodejs -y && npm i -g npm` 
 - Clone the repository by : 
 `git clone https://github.com/MrProgrammer72/GJ516Music && cd GJ516music` 
 - Install requirements by : 
 `pip3 install -U -r requirements.txt` 
 - Fill your variables in the env by : 
 `vi sample.env`<br> 
 Press `I` on the keyboard for editing env<br> 
 Press `Ctrl+C` when you're done with editing env and `:wq` to save the env<br> 
 - Rename the env file by : 
 `mv sample.env .env` 
 - Install tmux to keep running your bot when you close the terminal by : 
 `sudo apt install tmux && tmux` 
 - Finally run the bot by : 
 `bash GJ516` 
 - For getting out from tmux session<br> 
 Press `Ctrl+b` and then `d`



 </p> 

 </details>

━━━━━━━━━━━━━━━━━━━━ 

   <h3 align="center"> 
     ─「 sᴜᴩᴩᴏʀᴛ 」─ 
 </h3> 

  <p align="center"> 
 <a href="https://t.me/GJ516_DISCUSS_GROUP"><img src="https://img.shields.io/badge/-Support%20Group-blue.svg?style=for-the-badge&logo=Telegram"></a> 
 </p> 
 <p align="center"> 
 <a href="https://telegram.me/myworldGJ516"><img src="https://img.shields.io/badge/-Support%20Channel-blue.svg?style=for-the-badge&logo=Telegram"></a> 
 </p> 
━━━━━━━━━━━━━━━━━━━━
    <h3 align="center"> 
   ─「 ᴄʀᴇᴅɪᴛs 」─ 
 </h3> 

 - <b>[ᴅᴇᴠᴇʟᴏᴘᴇʀ](https://github.com/MrProgrammer72)  ➻  [sᴏᴍᴇᴛʜɪɴɢ](https://github.com/MrProgrammer72/GJ516VCBOT) </b> 
━━━━━━━━━━━━━━━━━━━━
